#include "gmp.h"
#include "gmp-impl.h"

__gmp_const int mp_bits_per_limb = BITS_PER_MP_LIMB;
