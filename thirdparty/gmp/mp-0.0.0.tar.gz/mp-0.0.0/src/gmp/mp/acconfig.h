/* Define this on x86 if align directive uses old syntax. */
#undef X86_BROKEN_ALIGN

/* Define this if an underscore gets prepended to external C names. */
#undef C_UNDERSCORE

/* Define this to disable assembly code in longlong.h. */
#undef NO_ASM
